'''
Created on Feb 11, 2017

@author: pande
'''
## Binary to hex

def main():
    bin = input("Enter a binary number: ")
    print("The corresponding hexadecimal number is",binaryToHex(bin))

def binaryToHex(bin):
    #slice the binary number into group of 4, starting from right
    l = len(bin)
    if l%4 == 0:
        part = l//4
        s = str()
        for k in range(0,part):
            stemp = bin[0:4]
            hex = 0
            j = 8
            i = 0
            for i in range(0,4):
                temp = stemp[i]
                hex = hex + (int(temp)*j)
                j = j//2         
            if hex>=10:
                hex = hex + 55
                hex = chr(hex)
            s = s+ str(hex)
            bin = bin[4:l]
        return s
    else:
        rem = l%4
        for c in range(4-rem,0,-1) :
            bin = "0" + bin
        l = len(bin)
        part = l//4
        s = str()
        for k in range(0,part):
            stemp = bin[0:4]
            hex = 0
            j = 8
            i = 0
            for i in range(0,4):
                temp = stemp[i]
                hex = hex + (int(temp)*j)
                j = j//2         
            if hex>=10:
                hex = hex + 55
                hex = chr(hex)
            s = s+ str(hex)
            bin = bin[4:l]
        return s      
main()
    
    
        