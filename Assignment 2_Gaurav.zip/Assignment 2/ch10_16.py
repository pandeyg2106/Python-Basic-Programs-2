
'''
Created on Feb 12, 2017

@author: pande
'''
## Bubblesort

def main():
    s = input("Enter 10 numbers in the list: ")
    items = s.split()
    list = [eval(x) for x in items]
    print("Bubble sort algorithm is starting:\n")
    bubblesort(list)

def bubblesort(list):
    sort = False
    while sort == False:
        i = 0
        count = 0
        for i in range(0,9):
            if list[i]<list[i+1]:
                if list[0] == min(list):
                    sort = True
            else:
                temp = list[i]
                list[i] = list[i+1]
                list[i+1] = temp
                print(list)
                sort = False
    print("Bubble sort algorithm finished successfully!")
main()