'''
Created on Feb 13, 2017

@author: pande
'''
## Program to merge two list and sort

def main():
    a = input("Enter list 1: ")
    items = a.split()
    list1 = [eval(x) for x in items]
    
    b = input("Enter list 1: ")
    items = b.split()
    list2 = [eval(x) for x in items]
    
    list3 = merge(list1,list2)
    print("The merged list is ", end = "")
    for i in list3:
        print(i, end = " ")
    

def merge(list1,list2):
    result = []
    i = 0       # Current index in list1
    j = 0       # Current index in list2
    
    while i<len(list1) and j<len(list2):
        if list1[i]<list2[j]:
            result.append(list1[i])
            i += 1
        else:
            result.append(list2[j])
            j += 1
    while i<len(list1):
        result.append(list1[i])
        i += 1
    while j<len(list2):
        result.append(list2[j])
        j += 1
    
    return result
main()
        
    