'''
Created on Feb 16, 2017

@author: pande
'''
def main():
    m,n = eval(input("Enter two integers: "))
    print("The GCD of "+str(m)+" and"+str(n)+" is:",gcd(m,n))
    
def gcd(m,n):
    if m % n == 0:
        return n
    else:
        return gcd(n,m%n)
main()