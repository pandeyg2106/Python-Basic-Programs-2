'''
Created on Feb 14, 2017

@author: pande
'''
## Largest row and column
import random

def initializeMatrix():
    matrix = []
    for row in range(4):
        matrix.append([])
        for col in range(4):
            matrix[row].append(random.randint(0,1))
            print(matrix[row][col], end = " ")
        print()
    largestrow(matrix)

def largestrow(matrix):
    rowSum = sum(matrix[0])
    rowList = [0]
    for i in range(1, 4):
        if rowSum < sum(matrix[i]):
            rowSum = sum(matrix[i])
            rowList = [i]
        elif rowSum == sum(matrix[i]):
            rowList.append(i)
            
    print("The largest row index: ", end = "")
    for i in range(len(rowList) - 1):
        print(rowList[i], end = ", ")
    print(rowList[len(rowList) - 1])
    
    largestcolumn(matrix)

def largestcolumn(matrix):
    columnSum = sumColumn(matrix, 0)
    columnList = [0]
    for j in range(1, 4):
        if columnSum < sumColumn(matrix, j):
            columnSum = sumColumn(matrix, j)
            columnList = [j]
        elif columnSum == sumColumn(matrix, j):
            columnList.append(j)
                
    print("The largest column index: ", end = "")
    for i in range(len(columnList) - 1):
        print(columnList[i], end = ", ")
    print(columnList[len(columnList) - 1])
    
def sumColumn(m, j):
    sum = 0
    for i in range(4):
        sum += m[i][j]
    return sum

def main():
    initializeMatrix()
    
main()