'''
Created on Feb 19, 2017

@author: pande
'''
from tkinter import *

class MoveBall:    
    def __init__(self): 
        window = Tk()
        window.title("The Moving ball")    
        self.width = 400
        self.height = 400
        self.canvas = Canvas(window, width = self.width, height = self.height, bg = "white")  
        self.canvas.pack()        
        self.x = 90
        self.y = 50        
        self.canvas.create_oval(self.x, self.y, self.x+20, self.y+20, tags = "ball", fill="green")       
        frame = Frame(window)
        frame.pack()        
        button_Left = Button(frame, text = "Left", command = self.moveLeft)
        button_Right = Button(frame, text = "Right", command = self.moveRight)
        button_Up = Button(frame, text = "Up", command = self.moveUp)
        button_Down = Button(frame, text = "Down", command = self.moveDown) 
        button_Left.grid(row = 1, column = 1)
        button_Right.grid(row = 1, column = 2)
        button_Up.grid(row = 1, column = 3)
        button_Down.grid(row = 1, column = 4)        
        window.mainloop()        
    def moveLeft(self):    #move left
        distx = 20
        self.canvas.move("ball", -distx, 0)
        self.canvas.update()
        
        if self.x > 0:
            self.x -= distx
        else:
            self.x = self.width
            self.canvas.delete("ball")
            self.canvas.create_oval(self.x-20, self.y, self.x, self.y+20, tags = "ball", fill="green")
    
    def moveRight(self):   # move right
        distx = 20
        self.canvas.move("ball", distx, 0)
        self.canvas.update()
        
        if self.x < self.width - 20:
            self.x += distx
        else:
            self.x = 0
            self.canvas.delete("ball")
            self.canvas.create_oval(self.x, self.y, self.x+20, self.y+20, tags = "ball", fill="green")

    def moveUp(self):     #move up
        disty = 10
        self.canvas.move("ball", 0, -disty)
        self.canvas.update()
        
        if self.y > 0:
            self.y -= disty
        else:
            self.y = self.height
            self.canvas.delete("ball")
            print(self.x)
            print(self.y-10)
            self.canvas.create_oval(self.x, self.y-20, self.x+20, self.y, tags = "ball", fill="green")
    
    def moveDown(self):  # move down
        disty = 10
        self.canvas.move("ball", 0, disty)
        self.canvas.update()
        
        if self.y < self.height - 10:
            self.y += disty
        else:
            self.y = 0
            self.canvas.delete("ball")
            self.canvas.create_oval(self.x, self.y, self.x+20, self.y+20, tags = "ball", fill="green")
        
MoveBall()
