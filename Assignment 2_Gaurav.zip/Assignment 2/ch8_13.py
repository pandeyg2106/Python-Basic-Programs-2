'''
Created on Feb 11, 2017

@author: pande
'''
## Longest common prefix of two strings

def main():
    s1 = input("Enter first string: ")
    s2 = input("Enter second string: ")
    print("Longest common prefix of these strings is",prefix(s1,s2))

def prefix(s1,s2):
    l1 = len(s1)
    l2 = len(s2)
    lcf = ""
    if l1<l2:
        for i in range(0,l1):
            if s1[i] == s2[i]:
                lcf = lcf + s1[i]
            else:
                return lcf
    else:
        for i in range(0,l2):
            if s2[i] == s1[i]:
                lcf = lcf + s2[i]
            else:
                return lcf
main()