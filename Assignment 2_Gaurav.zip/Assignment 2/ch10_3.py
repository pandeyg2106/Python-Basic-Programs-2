'''
Created on Feb 12, 2017

@author: pande
'''
## Program to count the occurrences of integer in a list

def main():
    n = input("Enter any integers between 1 and 100: ")
    items = n.split()
    list = [eval(x) for x in items]
    print(list)
    counter(list)

def counter(list):
    i = 0
    while len(list)!=0:
        count = list.count(list[i])
        if count > 1:
            print(list[i], "occurs",count,"times")
            j = 1
            n = list[i]
            while j<=count:
                list.remove(n)
                j += 1  
        else:
            n = list[i]
            print(list[i], "occurs",count,"time")
            list.remove(n)  
main()  