'''
Created on Feb 16, 2017

@author: pande
'''
## Recursive function to compute sum of digits in an integer

def main():
    n = eval(input("Enter any integer: "))
    print("The sum of digits in the integer is:",sumDigits(n))
    
def sumDigits(n):
    if n < 10:
        return n
    else:
        return n%10 + sumDigits(n//10)
main()