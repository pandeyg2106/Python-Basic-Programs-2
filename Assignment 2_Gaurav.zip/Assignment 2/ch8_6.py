'''
Created on Feb 11, 2017

@author: pande
'''
## count number of letters in a string
def main():
    s = input("Enter any string: ")
    print("Number of letters in the string are",countletters(s))

def countletters(s):
    l = len(s)
    count = 0
    for i in range(0,len(s)):
        if s[i].isdigit():
            count += 1
    letter = l - count
    return letter
main()