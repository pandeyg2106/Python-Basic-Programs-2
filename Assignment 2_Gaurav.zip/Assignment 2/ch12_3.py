'''
Created on Feb 18, 2017

@author: pande
'''
# Class Account
class Account:
# constructor
    def __init__(self):
        self.balance = 100.0
        self.id= 0
        self.annualInterestRate = 0.0
# Monthly Interest Rate    
    def getMonthlyInterestRate(self):
        return (self.annualInterestRate/100)/12
# Monthly Interest Amount   
    def getMonthlyInterest(self):
        return self.balance * self.getMonthlyInterestRate()
# Withdraw from balance   
    def withdraw(self,amount):
        self.balance=self.balance-amount
# Deposit to balance    
    def deposit(self,amount):
        self.balance=self.balance+amount
    def getId(self):
        return self.id
    def getBalance(self):
        return self.balance
    def getAnnualInterestRate(self):
        return self.annualInterestRate

class ATM(Account):
    def __init__(self, id):
        super().__init__()
        self.id = id
    def mainMenu(self):
        print("Main menu \n1: Check balance \n2: Withdraw \n3: Deposit \n4: Exit")

def main():
    account=[0,1,2,3,4,5,6,7,8,9]  
    while True:
        id1 = eval(input("Input your ID: "))
        if id1 in account:
            ATM1 = ATM(id1)
            ATM1.mainMenu()
            while True:
                choice = eval(input("Enter a choice:" ))
                if choice == 1:
                    print(ATM1.getBalance())
                    ATM1.mainMenu()
                elif choice == 2:
                    d = eval(input("Enter amount to withdraw: "))
                    ATM1.withdraw(d)
                    ATM1.mainMenu()
                elif choice == 3:
                    d = eval(input("Enter amount to Deposit: "))
                    ATM.deposit(d)
                    ATM1.mainMenu()
                elif choice == 4:
                    break
        else:
            print("Enter correct Choice")
        continue

main()