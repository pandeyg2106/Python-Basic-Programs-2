'''
Created on Feb 14, 2017

@author: pande
'''
### Add two matrices
##Inputting Values of matrix 1
def main():
    a = []
    b = []
    n1 = input("Enter matrix 1: ")
    items1 = n1.split()
    for row in range(3):
        m1 = [float(items1[col]) for col in range(3*row,3*row+3)]
        a.append(m1)

##Inputting values of matrix 2
    n2 = input("Enter matrix 2: ")
    items2 = n2.split()
    for row in range(3):
        m2 = [float(items2[col]) for col in range(3*row,3*row+3)]
        b.append(m2)
    
    c = addMatrix(a,b)
    printResult(a, b, c, "+")
    
def addMatrix(a,b):   
    c = [] 
    for i in range(3):
        c.append([])
        for j in range(3):
            sum = a[i][j] + b[i][j]
            c[i].append(sum)
    return c

def printResult(a, b, c, ab):
    for i in range(len(a)):
        for j in range(len(a[0])):
            print(" " + format(str(a[i][j]),"4s"), end = "")

        if i == len(a) // 2:
            print( "  " + ab + "  ", end = "")
        else:
            print( "     ", end = "")

        for j in range(len(b[0])):
            print(" " + format(str(b[i][j]),"4s"), end = "")

        if i == len(a) // 2:
            print("  =  ", end = "")
        else:
            print("     ", end = "")

        for j in range(len(c[0])):
            print(" " + format(str(c[i][j]),"4s"), end = "")

        print()
main()
            
            
    
    
    
