'''
Created on Feb 11, 2017

@author: pande
'''
### Check Substrings
def main():
    s2 = input("Enter first string: ")
    s1 = input("Enter second string: ")
    if findstr(s1,s2):
        print("First string is substring of second string")
    else:
        print("First string is not a substring of second string")

def findstr(string,substring):
    count = 0
    done = 0
    for i in range(0,len(string)):
        match = 1
        if string[i] == substring[0]:
            if len(string)-i >= len(substring):
                for j in range(0,len(substring)):
                    if string[i+j] != substring[j]:
                        match = 0
                        return False
                        break
                    else:
                        count += 1
                        if (match == 1) and (count == len(substring)):
                            done = 1
                            return True
                            break
            if done == 1:
                break

main()
                    
                    
                
    
    

