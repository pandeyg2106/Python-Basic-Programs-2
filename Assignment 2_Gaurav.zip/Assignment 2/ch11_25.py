'''
Created on Feb 15, 2017

@author: pande
'''
def main():
    m = []
    print("Enter a 3x3 matrix row by row:")
    for i in range(3):
        s = input(str())
        items = s.split()
        items1 = [eval(x) for x in items]
        m.append(items1)
    if isMarkovMatrix(m):
        print("It is a Markov matrix")
    else:
        print("It is not a Markov matrix")
               
def isMarkovMatrix(m):
    sum = 0
    for j in range(3):
        for i in range(len(m)):
            if m[i][j]>0:
                sum += m[i][j]
            else:
                return False
        if sum == 1:
            return True
        else:
            return False
main()
    
        