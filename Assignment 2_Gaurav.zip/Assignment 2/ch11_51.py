'''
Created on Feb 15, 2017

@author: pande
'''
from operator import itemgetter
def main():
    a = []
    b = []
    s = input("Enter student's name and scores in one line: ")
    items = s.split()
    for row in range(len(items)//2):
        m1 = [items[col] for col in range(2*row,2*row+1,2)]
        m2 = [eval(items[col]) for col in range(2*row+1,2*row+2,2)]
        a.append(m1)
        b.append(m2)
    d = []
    c = []
    for i in range(len(a)):
        temp1 = a[i]
        value1 = temp1[0]
        c.append(value1)
        temp2 = b[i]
        value2 = temp2[0]
        c.append(value2)
        d.append(c)
        c = []
    sort(d)
    
def sort(d):
    d.sort(key=itemgetter(1))
           
    for row in d:
        for value in row:
            print(format(str(value),"10s"), end =" ")
        print()
main()