'''
Created on Feb 14, 2017

@author: pande
'''

def main():
    matrix = []
    for i in range(1,5):
        n = str(input("Enter a 4-by-4 matrix row for row"+str(i)+": "))
        items = n.split()
        items2 = [eval(x) for x in items]
        matrix.append(items2)
    print("The sum of elements in major diagonal is",sumMajorDiagonal(matrix))    
def sumMajorDiagonal(matrix): 
    total = 0
    for row in range(len(matrix)):
        for col in range(len(matrix[row])):
            if row == col:
                total += matrix[row][col]
    return total
main()
        
        
    