'''
Created on Feb 18, 2017

@author: pande
'''
import os.path

def main():
    fl=input("Enter the filename :").strip()
    rem=input("Enter the string to be removed:")  
    if os.path.isfile(fl):
        infile=open(fl ,"r")    
        line=infile.read().split()
        
        infile.close()        
        outfile=open(fl ,"w")
        for i in line:
            if(rem!=i):
                outfile.write(i+" ")                                
            elif(rem==i):
                outfile.write(" ")    
        outfile.close()    
        print("Done")    
    else:
        print("Given filename does not exist")      
main()

# newfile=""
# 
# for i in read:
#     if s in i:#check if s is in file
#         newfile+="BBBB"#update new list with replacement else append file content
#     else:
#         newfile+=i
# n=open(filename,'w')#open file in write mode and append new data
# b=str(newfile)
# n.write(b)

# n.close()
