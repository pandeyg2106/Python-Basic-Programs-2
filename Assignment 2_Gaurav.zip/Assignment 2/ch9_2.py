'''
Created on Feb 19, 2017

@author: pande
'''
from tkinter import *    
class Calculate:    
    def __init__(self):
        window = Tk()
        window.title("Investment Value Calculator")        
        Label(window, text = "Invest Amount").grid(row = 1, column = 1)
        Label(window, text = "Years").grid(row = 2, column = 1)
        Label(window, text = "Annual Interest Rate").grid(row = 3, column = 1)
        Label(window, text = "Future Value").grid(row = 4, column = 1)        
        self.invAmount = StringVar()
        Entry(window, textvariable = self.invAmount, justify = RIGHT).grid(row = 1, column = 2)        
        self.annualIntRate = StringVar()
        Entry(window, textvariable = self.annualIntRate, justify = RIGHT).grid(row = 3, column = 2)        
        self.noOfYears = StringVar()
        Entry(window, textvariable = self.noOfYears, justify = RIGHT).grid(row = 2, column = 2)        
        self.futureValue = StringVar()        
        Label(window, textvariable = self.futureValue).grid(row = 4, column = 2)            
        Button(window, text = "Calculate", command = self.calculatefutureValue).grid(row = 6, column = 2)        
        window.mainloop()        
    def calculatefutureValue(self):
        monthlyIntRate = float(self.annualIntRate.get()) / (12*100)
        f = float(self.invAmount.get()) * (1 + monthlyIntRate) ** (float(self.noOfYears.get()) * 12)
        self.futureValue.set("{0:10.2f}".format(f))    
Calculate()