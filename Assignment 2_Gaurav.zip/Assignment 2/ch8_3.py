'''
Created on Feb 11, 2017

@author: pande
'''
## Check password

def main():
    pwd = input("Enter the password: ")
    if length(pwd) and alphanum(pwd) and NOofdigits(pwd):
        print("The password entered is Valid")
    else: 
        print("The password entered is Invalid")

def length(pwd):
    if len(pwd) < 8:
        return False
    else:
        return True
    
def alphanum(pwd):
    if pwd.isalnum():
        return True
    else:
        return False

def NOofdigits(pwd):
    count = 0
    for i in range(0,len(pwd)):
        if pwd[i].isdigit():
            count += 1
    if count < 2:
        return False
    else:
        return True
main()

    