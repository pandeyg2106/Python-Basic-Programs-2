'''
Created on Feb 12, 2017

@author: pande
'''
## Program to calculate standard deviation

def main():
    s = input("Enter your data points separated by space: ")
    items = s.split()
    x = [eval(x) for x in items]
    print("The mean of the data points is:",mean(x))
    print("The standard deviation of the data points is:",deviation(x))

def mean(x):
    sum = 0
    for i in range(len(x)):
        sum += x[i]
    mean = sum/len(x)
    return round(mean,2)

def deviation(x):
    sum = 0
    for i in range(len(x)):
        sum += ((x[i]-mean(x))*(x[i]-mean(x)))
    deviation = (sum/(len(x)-1))**0.5
    return round(deviation,5)
main()