'''
Created on Feb 12, 2017

@author: pande
'''
class Point:
    def __init__(self,x=0,y=0):
        self.__x = x
        self.__y= y
    
    def getx(self):
        return self.__x
    
    def gety(self):
        return self.__y
    
    def setx(self,x):
        self.__x = x
    
    def sety(self,y):
        self.__y = y    
    
    def distance(self,other):   
        return round(((self.__x - other.__x)**2 + (self.__y - other.__y)**2)**0.5,2)
    
    def isNearBy(self,p1):
        if self.distance(p1)<5:
            return True
        else:
            return False
    
    def __str__(self):
        return str(self.__x+self.__y)
        
x1,y1,x2,y2=(float(x) for x in input("Enter two points x1, y1, x2, y2:").split(','))
p1=Point(x1,y1)
p2=Point(x2,y2)
print("The distance between the two points is",p1.distance(p2))
if(p1.isNearBy(p2)):
    print("The two points are near each other")
else:
    print("The two points are not near each other")