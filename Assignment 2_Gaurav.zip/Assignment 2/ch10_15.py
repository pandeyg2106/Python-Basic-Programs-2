'''
Created on Feb 12, 2017

@author: pande
'''
#Program to check if the entered list is sorted.

def main():
    s = input("Enter numbers in the list: ")
    items = s.split()
    list = [eval(x) for x in items]
    if isSorted(list):
        print("The list is sorted")
    else:
        print("The list is not sorted")

def isSorted(list):
    sorted = True
    for i in range(len(list)-1):
        if list[i]<=list[i+1]:
            sorted = True
        else:
            return False
    if sorted == True:
        return True
main()
            