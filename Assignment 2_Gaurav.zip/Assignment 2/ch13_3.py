'''
Created on Feb 19, 2017

@author: pande
'''
filename=input("Enter a FileName")
f=open(filename,'r')

s=f.read()
list=[eval(x) for x in s.split()]
f.close()
total=len(list)
sum=0
for i in list:
    sum = sum+i

average=sum/total

print("There are",total," Scores")
print("The Total is",sum)
print("The Average is",average)