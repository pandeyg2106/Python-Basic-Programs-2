'''
Created on Feb 16, 2017

@author: pande
'''
#super class 
class GeometricObject:
    def __init__(self, color = "green", filled = True):
        self.__color = color
        self.__filled = filled

    def getColor(self):
        return self.__color

    def setColor(self, color):
        self.__color = color

    def isFilled(self):
        return self.__filled

    def setFilled(self, filled):
        self.__filled = filled
  
    def __str__(self):
        return "color: " + self.__color + \
            " and filled: " + str(self.__filled)
#syb class
class Triangle(GeometricObject):
    def __init__(self,side1=1.0,side2=1.0,side3=1.0):
        super().__init__()
        self.__side1=side1
        self.__side2=side2
        self.__side3=side3

    def getArea(self):
        s = (self.__side1 + self.__side2 + self.__side3) / 2
        return round(((s*(s-self.__side1)*(s-self.__side2)*(s-self.__side3)) ** 0.5),2)

    def getPerimeter(self):
        return(self.__side1+self.__side2+self.__side3)
    def __str__(self):
        return "Triangle: side1 = " + str(self.__side1) + " side2 = " +\
        str(self.__side1) + " side3 = " + str(self.__side1)
#user input and set new color and fill status and call area and perimeter
def main():
    s1,s2,s3,color,filled=eval(input("Enter sides 1,2,3 ,color(in double quotes), and filled (1 for True and 0 for false): "))
    t1=Triangle(s1,s2,s3)
    t1.setColor(color)
    if filled==0:
        t1.setFilled(filled=False)
    else:
        t1.setFilled(filled=True)
        
    
    print("The area of the triangle is: ",t1.getArea())
    print("The Perimeter of the triangle is: ",t1.getPerimeter())
    print("Color is: ",t1.getColor())
    print(t1.isFilled())

main()