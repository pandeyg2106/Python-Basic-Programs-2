'''
Created on Feb 12, 2017

@author: pande
'''
## Reverse contents of a list

def main():
    list = []
    s = input("Enter numbers: ")
    items = s.split()
    list = [eval(x) for x in items]
    print(list)
    print("The reversed list is:",reverse(list))

def reverse(list):
    n = len(list)
    k = n//2
    for j in range(0,k):
        temp = list[j]
        list[j] = list[(n-1)-j]
        list[(n-1)-j] = temp
    return list
main()