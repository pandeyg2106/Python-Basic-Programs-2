'''
Created on Feb 16, 2017

@author: pande
'''
def main():
    binaryString = str(input("Enter a binary number: "))
    print("The decimal equivalent is",binaryToDecimal(binaryString))
def binaryToDecimal(binaryString):
    num = int(binaryString)%10
    if int(binaryString) == 0:
        return 0
    else:
        return num + 2*(binaryToDecimal(int(binaryString)//10))
main()