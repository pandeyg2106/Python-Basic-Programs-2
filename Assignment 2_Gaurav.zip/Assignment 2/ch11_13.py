'''
Created on Feb 15, 2017

@author: pande
'''
def main():
    n = eval(input("Enter the number of rows in the list: "))
    a = []
    for i in range(n):
        s = str(input("Enter row"+str(i)+": "))
        items = s.split()
        items2 = [eval(x) for x in items]
        a.append(items2)
    print(a)
    locatelargest(a)
def locatelargest(a):
    lst = [0]
    greatest = 0
    for row in range(len(a)):
        for col in range(len(a[row])):
            if a[row][col]>greatest:
                greatest = a[row][col] 
                lst = [row]
                lst.append(col)
    print("The location of the largest element is at: ",end='')
    for i in range(len(lst)-1):
        print("("+str(lst[i])+",",end='')
    print(str(lst[len(lst)-1])+")")
    
main()            
    