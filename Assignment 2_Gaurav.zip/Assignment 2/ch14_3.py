'''
Created on Feb 16, 2017

@author: pande
'''
def main():
# Prompt the user to enter a file
    filename = input("Enter a filename: ").strip()
    infile = open(filename, "r")
    wordCounts = {}
    
    # Create an empty dictionary to count words
    for line in infile:
        processLine(line.lower(), wordCounts)
    pairs = list(wordCounts.items())
    items = [[x, y] for (y, x) in pairs]
    
    for i in range(len(items)):
        print(format(items[i][1],"15s") + "\t" + str(items[i][0]))

# Count each word in the line
def processLine(line, wordCounts):
    line = replacePunctuations(line) # Replace punctuation with space
    words = line.split()
    # Get words from each line
    for word in words:
        if word in wordCounts:
            wordCounts[word] += 1
        else:
            wordCounts[word] = 1
 # Replace punctuation in the line with a space
def replacePunctuations(line):
    for ch in line:
        if ch in "~@#$%^&*()_-+=~<>?/,.;:!{}[]|'\"":
            line = line.replace(ch, " ")
    return line

main()